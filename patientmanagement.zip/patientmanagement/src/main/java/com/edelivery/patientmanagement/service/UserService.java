package com.edelivery.patientmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.edelivery.patientmanagement.entity.User;

@Service
public interface UserService {
	public List<User> findAll();

	public User findById(int theId);

	public User save(User user);

	public boolean delete(int userid);

	public List<User> findOldUserRecords();
}
