package com.edelivery.patientmanagement.job;

import java.util.List;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.edelivery.patientmanagement.entity.User;
import com.edelivery.patientmanagement.service.SendEmailService;
import com.edelivery.patientmanagement.service.UserService;

@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "scheduling.enabled", matchIfMissing = true)
public class SchedulerConfiguration {

	public static final Logger LOG = Logger.getLogger(SchedulerConfiguration.class);
	@Autowired
	SendEmailService sendEmailService;

	@Autowired
	UserService userService;

	@Scheduled(cron = "* * * * * *")
	void deleteUsersAndSendEmail() {
		LOG.debug("Starting CRON JOB to delete old users and notify admin");
		List<User> users = userService.findOldUserRecords();
		if (users == null || users.size() == 0) {
			LOG.debug("No user records are found ");
			return;
		}
		for (User user : users) {
			if (userService.delete(user.getUser_id())) {
				LOG.debug("User " + user.getUsername() + " deleted successfully");
			} else {
				LOG.debug("Failed to create user");
			}
		}
		String deletedUserNames = users.stream().map(user -> user.getUsername()).collect(Collectors.joining(","));
		sendEmailService.sendEmail(deletedUserNames);
	}
}
