package com.edelivery.patientmanagement.service.impl;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.edelivery.patientmanagement.service.SendEmailService;

@Service
class SendEmailServiceImpl implements SendEmailService {

	public static final Logger LOG = Logger.getLogger(SendEmailServiceImpl.class);

	@Autowired
	private JavaMailSender javaMailSender;

	public void sendEmail(String deletedUserNames) {
		LOG.debug("Email start");
		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		simpleMailMessage.setFrom("vidhya8547@gmail.com");
		simpleMailMessage.setTo("vishnur3006@gmail.com");
		simpleMailMessage.setSubject("Test Subject");
		simpleMailMessage.setText("Deleted users are: " + deletedUserNames);
		javaMailSender.send(simpleMailMessage);
		LOG.debug("Email send");
	}
}