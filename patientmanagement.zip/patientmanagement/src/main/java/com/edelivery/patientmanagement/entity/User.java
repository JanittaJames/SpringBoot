package com.edelivery.patientmanagement.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.cache.annotation.Cacheable;

@Entity
@Table(name = "users")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	
	@NotBlank(message = "Please enter username!")
	@Column(name="user_name",	unique = true)
	private String username;

	@NotBlank(message = "Please enter email id!")
	@Column(unique = true)
	private String email;
	
	@NotBlank(message = "Please enter contact no!")
	@Column(unique = true)
	private String contact;
	
	
	@CreationTimestamp
	private Timestamp registrationTime;
	

	
	public int getUser_id() {
		return id;
	}


	public void setUser_id(int id) {
		this.id = id;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public Timestamp getRegistrationTime() {
		return registrationTime;
	}


	public void setRegistrationTime(Timestamp registrationTime) {
		this.registrationTime = registrationTime;
	}


		

}
