package com.edelivery.patientmanagement.service;

import org.springframework.stereotype.Service;

@Service
public interface SendEmailService {
	public void sendEmail(String deletedUserNames);

}
