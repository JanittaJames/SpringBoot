package com.edelivery.patientmanagement.service.impl;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edelivery.patientmanagement.dao.UserRepository;
import com.edelivery.patientmanagement.entity.User;
import com.edelivery.patientmanagement.service.UserService;

@Service

public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	public List<User> findAll() {
		return userRepository.findAll();

	}

	public User findById(int userId) {
		Optional<User> userResult = userRepository.findById(userId);
		if (userResult.isPresent()) {
			return userResult.get();
		} else {
			throw new RuntimeException("User " + userId + " not found");
		}
	}

	public User save(User user) {

		return userRepository.save(user);
	}

	public boolean delete(int id) {
		try {
			userRepository.deleteById(id);
			return true;
		} catch (Exception e) {

			return false;

		}
	}

	public List<User> findOldUserRecords() {
		LocalDateTime ldt = LocalDateTime.now();

		// subtract 7 DAYS to LocalDateTime
		LocalDateTime value = ldt.minus(7, ChronoUnit.DAYS);
		Timestamp timestamp = Timestamp.valueOf(value);

		return userRepository.findOldRecords(timestamp);

	}

}
